HOW TO USE:
    - BY COMMAND /showtextui [KEY] [TITLE] [TEXT]
    - example: /showtextui E COS_SCRIPTS Press the button E

    - BY EVENT: 

        SHOW
        TriggerEvent('cos_textui:show', key, title, action)
        example: TriggerEvent('cos_textui:show', "E", "COS-SCRIPTS", "PRESS THE BUTTON")

        HIDE
        TriggerEvent('cos_textui:hide')


DISCORD: https://discord.gg/PD4dWVAxGR

BY: COS_Scripts